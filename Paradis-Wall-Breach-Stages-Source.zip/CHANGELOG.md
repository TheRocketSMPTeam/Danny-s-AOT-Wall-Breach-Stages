# Update notes

## 1.0.6

- Added a server-side entity-load safeguard to remove restricted titans that bypass the normal spawn hook.
- Remove restricted titans inside the active wall boundary when they load from saved chunks.

## 1.0.5

- Prevent Sawney and Beard Titan from bypassing the active non-shifter spawn boundary.
- Treat Danny's Beard Titan class names as titans instead of excluding them as titan parts.

## 1.0.4

- Default to no breached walls, with the 13,660-block Wall Maria boundary.
- Set `/wallbreach maria` to 7,614 blocks and `/wallbreach rose` to 1,616 blocks.
- Set `/wallbreach sina` to allow spawning anywhere; add `/wallbreach none` and `/wallbreach no_breaches` to restore the default boundary.

## 1.0.3

- Fixed the Paradis dimension check used by the spawn boundary.
- Explicitly keeps Sawney restricted by the active wall boundary.
- Preserved unrestricted spawning for player-shifter forms.

## 1.0.2

- Replaced numbered stages with `/wallbreach maria`, `/wallbreach rose`, and `/wallbreach sina`.
- Added `/wallbreach all` to allow titans to spawn anywhere in Paradis.
- Allowed player-shifter forms to spawn without wall-boundary restrictions.
- Improved recognition of Fatahh, Connie's Father, Yellow, and Tropical titans.
