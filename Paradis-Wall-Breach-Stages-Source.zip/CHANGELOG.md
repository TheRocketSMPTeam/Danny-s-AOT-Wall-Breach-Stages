# Update notes

## 1.0.3

- Fixed the Paradis dimension check used by the spawn boundary.
- Explicitly keeps Sawney restricted by the active wall boundary.
- Preserved unrestricted spawning for player-shifter forms.

## 1.0.2

- Replaced numbered stages with `/wallbreach maria`, `/wallbreach rose`, and `/wallbreach sina`.
- Added `/wallbreach all` to allow titans to spawn anywhere in Paradis.
- Allowed player-shifter forms to spawn without wall-boundary restrictions.
- Improved recognition of Fatahh, Connie's Father, Yellow, and Tropical titans.
