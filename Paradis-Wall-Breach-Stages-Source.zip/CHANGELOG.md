# Update notes

## 1.0.12

- Detects Danny's AOT titan bodies using registered entity IDs, including `dannys-aot:sawney` and `dannys-aot:small_titan`.
- Reports the number of Paradis worlds scanned and restricted titans removed when a wall command is used.

## 1.0.11

- Purges already-loaded restricted titans when a wall command is used.
- Adds a final sweep at the tail of each server tick, after other mods' spawn callbacks.
- Reports the number of currently loaded restricted titans removed by a wall command.

## 1.0.10

- Runs the cleanup after all server world-spawn callbacks.
- Checks multipart titan hitboxes through their parent, without treating them as independent titans.
- Removes the Falco's Pure Titan family-name exemption; player-shifter forms remain allowed through Danny's shifter marker.

## 1.0.9

- Restored exclusions for attached titan hitboxes such as eyes, napes, grabs, and legs.
- Added an end-of-world-tick sweep that removes restricted titan bodies after spawn logic runs.

## 1.0.8

- Applies the active boundary to multipart titan hitboxes, including eyes, napes, grabs, and legs.
- Keeps attached parts of known player-shifter forms exempt.

## 1.0.7

- Added a server tick safeguard that removes restricted Danny's AOT titans if other spawn checks are bypassed.
- Stops restricted titans from remaining or acting inside the active boundary.

## 1.0.6

- Added a server-side entity-load safeguard to remove restricted titans that bypass the normal spawn hook.
- Remove restricted titans inside the active wall boundary when they load from saved chunks.

## 1.0.5

- Prevent Sawney and Beard Titan from bypassing the active non-shifter spawn boundary.
- Treat Danny's Beard Titan class names as titans instead of excluding them as titan parts.

## 1.0.4

- Default to no breached walls, with the 13,660-block Wall Maria boundary.
- Set `/wallbreach maria` to 7,614 blocks and `/wallbreach rose` to 1,616 blocks.
- Set `/wallbreach sina` to allow spawning anywhere; add `/wallbreach none` and `/wallbreach no_breaches` to restore the default boundary.

## 1.0.3

- Fixed the Paradis dimension check used by the spawn boundary.
- Explicitly keeps Sawney restricted by the active wall boundary.
- Preserved unrestricted spawning for player-shifter forms.

## 1.0.2

- Replaced numbered stages with `/wallbreach maria`, `/wallbreach rose`, and `/wallbreach sina`.
- Added `/wallbreach all` to allow titans to spawn anywhere in Paradis.
- Allowed player-shifter forms to spawn without wall-boundary restrictions.
- Improved recognition of Fatahh, Connie's Father, Yellow, and Tropical titans.
