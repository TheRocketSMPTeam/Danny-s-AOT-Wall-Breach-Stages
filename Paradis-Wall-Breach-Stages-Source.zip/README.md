# Paradis Wall Breach Stages

Control three Paradis wall breach stages in Minecraft 1.21.1 Fabric. Titans can spawn only beyond 13,660 blocks in Stage 1, 7,614 in Stage 2, and 1,616 in Stage 3. Advance stages with operator commands to simulate each wall being breached. Requires Danny's AOT and Fabric API.

## Commands

- `/wallbreach stage1` — Titans can spawn only outside a 13,660-block radius from Paradis center `(0, 0)`.
- `/wallbreach stage2` — Titans can spawn only outside a 7,614-block radius.
- `/wallbreach stage3` — Titans can spawn only outside a 1,616-block radius.

The stage is shared by the server and resets to Stage 1 when the server restarts. The radius is measured from `(0, 0)` in the `dannys-aot:paradis` dimension, following its concentric-wall layout. These rules block new titan spawns inside the active boundary; they do not remove titans that already exist.

The mod recognizes Danny's AOT titan classes, including Sawney, Mario, and Connie's Father, while excluding titan parts such as napes, eyes, grabs, and legs.

## Installation

Place the mod jar in the Fabric 1.21.1 instance's `mods` folder alongside Danny's AOT and Fabric API.

## License

Original code and assets are All Rights Reserved by The RocketSMP Team. See `LICENSE.txt` (also included in the mod jar).

