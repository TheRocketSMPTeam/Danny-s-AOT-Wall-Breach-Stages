# Paradis Wall Breach Stages

Control Paradis wall breach boundaries in Minecraft 1.21.1 Fabric. The default is no breaches: non-shifter titans are kept beyond the 13,660-block Wall Maria boundary. As walls are breached, that limit moves inward. Danny's AOT player-shifter forms (including Colossal, Armored, Cart, Jaw, Warhammer, Female, Attack, and other forms marked by the mod) can spawn at any distance. Requires Danny's AOT and Fabric API.

Version 1.0.7 adds a server tick safeguard that removes restricted AOT titans that bypass the spawn and entity-load checks. Version 1.0.6 added an entity-load safeguard. Version 1.0.5 explicitly restricts Sawney and Beard Titan to the active boundary. Version 1.0.4 starts with no breaches and uses the requested Wall Maria, Rose, and Sina boundaries. Version 1.0.3 made the Paradis dimension check direct.

## Commands

- `/wallbreach none` or `/wallbreach no_breaches` — No walls breached; non-shifter titans can spawn only outside a 13,660-block radius from Paradis center `(0, 0)`.
- `/wallbreach maria` — Wall Maria breached; non-shifter titans can spawn only outside a 7,614-block radius.
- `/wallbreach rose` — Wall Rose breached; non-shifter titans can spawn only outside a 1,616-block radius.
- `/wallbreach sina` or `/wallbreach all` — Wall Sina breached; non-shifter titans can spawn anywhere in Paradis.

The selected wall is shared by the server and resets to no breaches when the server restarts. The radius is measured from `(0, 0)` in the `dannys-aot:paradis` dimension, following its concentric-wall layout. These rules block new non-shifter titan spawns inside the active boundary; they do not remove titans that already exist.

The mod recognizes Danny's AOT titan classes, including Fatahh, Connie's Father, Sawney, Beard, Mario, Yellow, and Tropical titans, while excluding titan parts such as napes, eyes, grabs, and legs. It exempts player-shifter forms using Danny's AOT `ShifterTitan` marker, so those forms are not restricted by the wall boundary.

## Installation

Place the mod jar in the Fabric 1.21.1 instance's `mods` folder alongside Danny's AOT and Fabric API.

## License

Original code and assets are All Rights Reserved by The RocketSMP Team. See `LICENSE.txt` (also included in the mod jar).

