# Paradis Wall Breach Stages

Control Paradis wall breach boundaries in Minecraft 1.21.1 Fabric. The default is no breaches: non-shifter titans are kept beyond the 13,660-block Wall Maria boundary. As walls are breached, that limit moves inward. Danny's AOT player-shifter forms (including Colossal, Armored, Cart, Jaw, Warhammer, Female, Attack, and other forms marked by the mod) can spawn at any distance. Requires Danny's AOT and Fabric API.

Version 1.0.12 identifies Danny's AOT titan bodies by their registered entity IDs and reports how many Paradis worlds and restricted titans were found when a breach command runs. Version 1.0.11 immediately removed loaded restricted titans when a breach command was set and added a final server-tick sweep. Version 1.0.10 moved cleanup after world spawn callbacks and followed hitboxes to parent titans. Version 1.0.9 added a sweep and restored hitbox exclusions. Version 1.0.8 applied the boundary to multipart hitboxes. Version 1.0.7 added a server tick safeguard. Version 1.0.6 added an entity-load safeguard. Version 1.0.5 explicitly restricts Sawney and Beard Titan to the active boundary. Version 1.0.4 starts with no breaches and uses the requested Wall Maria, Rose, and Sina boundaries. Version 1.0.3 made the Paradis dimension check direct.

## Commands

- `/wallbreach none` or `/wallbreach no_breaches` — No walls breached; non-shifter titans can spawn only outside a 13,660-block radius from Paradis center `(0, 0)`.
- `/wallbreach maria` — Wall Maria breached; non-shifter titans can spawn only outside a 7,614-block radius.
- `/wallbreach rose` — Wall Rose breached; non-shifter titans can spawn only outside a 1,616-block radius.
- `/wallbreach sina` or `/wallbreach all` — Wall Sina breached; non-shifter titans can spawn anywhere in Paradis.

The selected wall is shared by the server and resets to no breaches when the server restarts. The radius is measured from `(0, 0)` in the `dannys-aot:paradis` dimension, following its concentric-wall layout. These rules block new non-shifter titan spawns inside the active boundary; they do not remove titans that already exist.

The mod recognizes Danny's AOT titan classes, including Fatahh, Connie's Father, Sawney, Beard, Mario, Yellow, and Tropical titans. Attached hitbox entities such as napes, eyes, grabs, and legs are excluded from the titan-body check to avoid invisible cubes. Player-shifter forms remain exempt.

## Installation

Place the mod jar in the Fabric 1.21.1 instance's `mods` folder alongside Danny's AOT and Fabric API.

## License

Original code and assets are All Rights Reserved by The RocketSMP Team. See `LICENSE.txt` (also included in the mod jar).

