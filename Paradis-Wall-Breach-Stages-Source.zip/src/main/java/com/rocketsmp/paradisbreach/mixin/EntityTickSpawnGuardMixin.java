package com.rocketsmp.paradisbreach.mixin;

import com.rocketsmp.paradisbreach.ParadisWallBreachMod;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Removes restricted AOT titans if another mod bypassed entity insertion checks. */
@Mixin(targets = "net.minecraft.class_1297", remap = false)
public abstract class EntityTickSpawnGuardMixin {
    @Inject(method = "method_5773()V", at = @At("HEAD"), remap = false, cancellable = true)
    private void paradisWallBreach$removeRestrictedTitan(CallbackInfo ci) {
        class_1297 entity = (class_1297) (Object) this;
        if (!entity.getClass().getName().startsWith("daot.")) {
            return;
        }

        class_1937 world = entity.method_37908();
        if (!world.method_8608() && ParadisWallBreachMod.shouldBlockTitanSpawn(entity, world)) {
            entity.method_31472();
            ci.cancel();
        }
    }
}
