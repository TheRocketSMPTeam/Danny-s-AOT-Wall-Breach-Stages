package com.rocketsmp.paradisbreach.mixin;

import com.rocketsmp.paradisbreach.ParadisWallBreachMod;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Stops a new titan from being inserted into Paradis inside the active wall. */
@Mixin(targets = "net.minecraft.class_3218", remap = false)
public abstract class ServerWorldSpawnMixin {
    @Inject(method = "method_14175(Lnet/minecraft/class_1297;)Z", at = @At("HEAD"),
            remap = false, cancellable = true, require = 1)
    private void paradisWallBreach$checkTitanSpawn(class_1297 entity,
            CallbackInfoReturnable<Boolean> cir) {
        if (ParadisWallBreachMod.shouldBlockTitanSpawn(entity, this)) {
            cir.setReturnValue(false);
        }
    }
}
