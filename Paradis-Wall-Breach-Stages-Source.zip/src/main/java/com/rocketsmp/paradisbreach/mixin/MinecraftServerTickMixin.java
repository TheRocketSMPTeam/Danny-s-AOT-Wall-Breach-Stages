package com.rocketsmp.paradisbreach.mixin;

import com.rocketsmp.paradisbreach.ParadisWallBreachMod;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Final cleanup after all server tick and mod spawn callbacks have run. */
@Mixin(targets = "net.minecraft.server.MinecraftServer", remap = false)
public abstract class MinecraftServerTickMixin {
    @Inject(method = "method_3813(Ljava/util/function/BooleanSupplier;)V", at = @At("TAIL"),
            remap = false, require = 1)
    private void paradisWallBreach$finalTitanSweep(java.util.function.BooleanSupplier shouldKeepTicking,
            CallbackInfo ci) {
        MinecraftServer server = (MinecraftServer) (Object) this;
        for (class_3218 world : server.method_3738()) {
            ParadisWallBreachMod.removeRestrictedTitans(world);
        }
    }
}
