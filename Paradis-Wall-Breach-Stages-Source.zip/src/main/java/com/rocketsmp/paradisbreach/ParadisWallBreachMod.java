package com.rocketsmp.paradisbreach;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;

    /** The configured wall boundary resets to no breaches on each server start. */
public final class ParadisWallBreachMod implements ModInitializer {
    private static final Logger LOGGER = Logger.getLogger("paradis_wall_breach_stages");
    // Command order and corresponding inner boundaries, in blocks from (0, 0).
    // The no-breaches state protects all land inside Wall Maria. Sina means no boundary.
    private static final String[] BREACHES = {"none", "maria", "rose", "sina"};
    private static final double[] INNER_BOUNDARIES = {13_660.0, 7_614.0, 1_616.0, 0.0};
    private static final AtomicInteger BREACH = new AtomicInteger(0);

    @Override
    public void onInitialize() {
        BREACH.set(0);
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                registerCommands(dispatcher));
        // Backup for spawn paths that bypass ServerWorld's normal add-entity method,
        // and for restricted titans already saved inside the active wall boundary.
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (shouldBlockTitanSpawn(entity, world)) {
                entity.method_31472();
            }
        });
        LOGGER.info("Paradis Wall Breach Stages loaded with no walls breached ("
                + (int) INNER_BOUNDARIES[0] + " blocks).");
    }

    private static void registerCommands(CommandDispatcher<class_2168> dispatcher) {
        LiteralArgumentBuilder<class_2168> root = LiteralArgumentBuilder.<class_2168>literal("wallbreach")
                .requires(source -> source.method_9259(2))
                .then(LiteralArgumentBuilder.<class_2168>literal("none")
                        .executes(context -> setBreach(context, 0)))
                .then(LiteralArgumentBuilder.<class_2168>literal("no_breaches")
                        .executes(context -> setBreach(context, 0)))
                .then(LiteralArgumentBuilder.<class_2168>literal("maria")
                        .executes(context -> setBreach(context, 1)))
                .then(LiteralArgumentBuilder.<class_2168>literal("rose")
                        .executes(context -> setBreach(context, 2)))
                .then(LiteralArgumentBuilder.<class_2168>literal("sina")
                        .executes(context -> setBreach(context, 3)))
                .then(LiteralArgumentBuilder.<class_2168>literal("all")
                        .executes(context -> setBreach(context, 3)));
        dispatcher.register(root);
    }

    private static int setBreach(CommandContext<class_2168> context, int breach) {
        BREACH.set(breach);
        int removed = 0;
        int paradisWorlds = 0;
        for (class_3218 world : context.getSource().method_9211().method_3738()) {
            if (isParadis(world)) {
                paradisWorlds++;
            }
            removed += removeRestrictedTitans(world);
        }
        String wall = breach == 0 ? "No walls breached"
                : "Wall " + capitalize(BREACHES[breach]) + " breached";
        String detail = breach == 3
                ? "Danny's AOT titans may spawn anywhere in Paradis."
                : "non-shifter titans may spawn only outside " + (int) INNER_BOUNDARIES[breach]
                        + " blocks from the center.";
        context.getSource().method_9226(() -> class_2561.method_43470(wall + ". " + detail), false);
        int removedCount = removed;
        int worldCount = paradisWorlds;
        context.getSource().method_9226(() -> class_2561.method_43470(
                "Scanned " + worldCount + " Paradis world(s); removed " + removedCount
                        + " restricted titan(s) inside the boundary."), false);
        return 1;
    }

    private static String capitalize(String value) {
        return Character.toUpperCase(value.charAt(0)) + value.substring(1);
    }

    public static boolean shouldBlockTitanSpawn(class_1297 entity, Object world) {
        if (!isParadis((class_1937) world)) {
            return false;
        }

        if (isTitanPart(entity)) {
            class_1297 parent = getTitanParent(entity);
            return parent != null && parent != entity && shouldBlockTitanBody(parent);
        }

        return shouldBlockTitanBody(entity);
    }

    private static boolean shouldBlockTitanBody(class_1297 entity) {
        if (!isDannyTitan(entity)) {
            return false;
        }
        // These Danny's AOT mobs are non-shifters and must always obey the boundary.
        String typePath = entityTypePath(entity);
        boolean forcedNonShifter = typePath.equals("sawney")
                || typePath.equals("titan_beard")
                || typePath.equals("beard_titan");
        if (!forcedNonShifter && isPlayerShifterForm(entity.getClass())) {
            return false;
        }

        double radius = INNER_BOUNDARIES[BREACH.get()];
        double distanceFromCenter = Math.hypot(entity.method_23317(), entity.method_23321());
        return distanceFromCenter < radius;
    }

    private static boolean isTitanPart(class_1297 entity) {
        return isTitanPartPath(entityTypePath(entity));
    }

    private static boolean isTitanPartPath(String path) {
        return path.contains("nape") || path.contains("eye") || path.contains("grab")
                || path.contains("leg") || path.contains("hand") || path.contains("spike")
                || path.contains("shell") || path.contains("projectile") || path.contains("dummy");
    }

    private static class_1297 getTitanParent(class_1297 part) {
        for (String methodName : new String[] {"getParentTitan", "pureTitanOwner"}) {
            try {
                Object parent = part.getClass().getMethod(methodName).invoke(part);
                if (parent instanceof class_1297 titan) {
                    return titan;
                }
            } catch (ReflectiveOperationException ignored) {
                // This part type does not expose a parent through this method.
            }
        }
        return null;
    }

    /** Sweep loaded entities after all mods' spawn logic, removing blocked titan roots. */
    public static int removeRestrictedTitans(class_3218 world) {
        if (!isParadis(world)) {
            return 0;
        }

        List<class_1297> blocked = new ArrayList<>();
        for (class_1297 entity : world.method_27909()) {
            if (isDannyAotEntity(entity)
                    && shouldBlockTitanSpawn(entity, world)) {
                blocked.add(entity);
            }
        }
        for (class_1297 entity : blocked) {
            entity.method_31472();
        }
        return blocked.size();
    }

    private static boolean isParadis(class_1937 world) {
        return world.method_27983().toString().contains("dannys-aot:paradis");
    }

    private static boolean isDannyTitan(class_1297 entity) {
        String typeId = class_1299.method_5890(entity.method_5864()).toString();
        if (!typeId.startsWith("dannys-aot:")) {
            return false;
        }

        String path = typeId.substring(typeId.indexOf(':') + 1).toLowerCase(java.util.Locale.ROOT);
        return (path.contains("titan") || path.startsWith("sawney") || path.startsWith("connie_father"))
                && !isTitanPartPath(path);
    }

    private static boolean isDannyAotEntity(class_1297 entity) {
        return class_1299.method_5890(entity.method_5864()).toString().startsWith("dannys-aot:");
    }

    private static String entityTypePath(class_1297 entity) {
        String id = class_1299.method_5890(entity.method_5864()).toString();
        int separator = id.indexOf(':');
        return (separator >= 0 ? id.substring(separator + 1) : id).toLowerCase(java.util.Locale.ROOT);
    }

    /** Danny's AOT marks every player-shift titan form with daot.ShifterTitan. */
    private static boolean isPlayerShifterForm(Class<?> entityClass) {
        String simpleName = entityClass.getSimpleName().toLowerCase(java.util.Locale.ROOT);
        // Some attached hitbox/part entities do not implement ShifterTitan, so
        // recognize their shifter family names to keep player-shift forms working.
        if (isKnownShifterFamily(simpleName)) {
            return true;
        }
        for (Class<?> current = entityClass; current != null; current = current.getSuperclass()) {
            for (Class<?> implemented : current.getInterfaces()) {
                if (implemented.getName().equals("daot.ShifterTitan") || hasShifterMarker(implemented)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean isKnownShifterFamily(String name) {
        return name.startsWith("attacktitan")
                || name.startsWith("armoredtitan")
                || name.startsWith("beasttitan")
                || name.startsWith("colossaltitan")
                || name.startsWith("femaletitan")
                || name.startsWith("foundingtitan")
                || name.startsWith("warhammer")
                || name.startsWith("cartshifter")
                || name.startsWith("ogreshifter")
                || name.startsWith("testshifter")
                || name.startsWith("triplettitan")
                || name.startsWith("femalecrystalshell")
                || name.startsWith("crystalshellwarhammer");
    }

    private static boolean hasShifterMarker(Class<?> type) {
        for (Class<?> parent : type.getInterfaces()) {
            if (parent.getName().equals("daot.ShifterTitan") || hasShifterMarker(parent)) {
                return true;
            }
        }
        return false;
    }
}
