package com.rocketsmp.paradisbreach;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;

    /** The configured wall boundary resets to no breaches on each server start. */
public final class ParadisWallBreachMod implements ModInitializer {
    private static final Logger LOGGER = Logger.getLogger("paradis_wall_breach_stages");
    // Command order and corresponding inner boundaries, in blocks from (0, 0).
    // The no-breaches state protects all land inside Wall Maria. Sina means no boundary.
    private static final String[] BREACHES = {"none", "maria", "rose", "sina"};
    private static final double[] INNER_BOUNDARIES = {13_660.0, 7_614.0, 1_616.0, 0.0};
    private static final AtomicInteger BREACH = new AtomicInteger(0);

    @Override
    public void onInitialize() {
        BREACH.set(0);
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                registerCommands(dispatcher));
        LOGGER.info("Paradis Wall Breach Stages loaded with no walls breached ("
                + (int) INNER_BOUNDARIES[0] + " blocks).");
    }

    private static void registerCommands(CommandDispatcher<class_2168> dispatcher) {
        LiteralArgumentBuilder<class_2168> root = LiteralArgumentBuilder.<class_2168>literal("wallbreach")
                .requires(source -> source.method_9259(2))
                .then(LiteralArgumentBuilder.<class_2168>literal("none")
                        .executes(context -> setBreach(context, 0)))
                .then(LiteralArgumentBuilder.<class_2168>literal("no_breaches")
                        .executes(context -> setBreach(context, 0)))
                .then(LiteralArgumentBuilder.<class_2168>literal("maria")
                        .executes(context -> setBreach(context, 1)))
                .then(LiteralArgumentBuilder.<class_2168>literal("rose")
                        .executes(context -> setBreach(context, 2)))
                .then(LiteralArgumentBuilder.<class_2168>literal("sina")
                        .executes(context -> setBreach(context, 3)))
                .then(LiteralArgumentBuilder.<class_2168>literal("all")
                        .executes(context -> setBreach(context, 3)));
        dispatcher.register(root);
    }

    private static int setBreach(CommandContext<class_2168> context, int breach) {
        BREACH.set(breach);
        String wall = breach == 0 ? "No walls breached"
                : "Wall " + capitalize(BREACHES[breach]) + " breached";
        String detail = breach == 3
                ? "Danny's AOT titans may spawn anywhere in Paradis."
                : "non-shifter titans may spawn only outside " + (int) INNER_BOUNDARIES[breach]
                        + " blocks from the center.";
        context.getSource().method_9226(() -> class_2561.method_43470(wall + ". " + detail), false);
        return 1;
    }

    private static String capitalize(String value) {
        return Character.toUpperCase(value.charAt(0)) + value.substring(1);
    }

    public static boolean shouldBlockTitanSpawn(class_1297 entity, Object world) {
        if (!isParadis((class_1937) world) || !isDannyTitan(entity)) {
            return false;
        }

        // These Danny's AOT mobs are non-shifters and must always obey the boundary.
        String simpleName = entity.getClass().getSimpleName().toLowerCase();
        boolean forcedNonShifter = simpleName.equals("sawneyentity")
                || simpleName.equals("titanbeardentity")
                || simpleName.equals("beardtitanentity");
        if (!forcedNonShifter && isPlayerShifterForm(entity.getClass())) {
            return false;
        }

        double radius = INNER_BOUNDARIES[BREACH.get()];
        double distanceFromCenter = Math.hypot(entity.method_23317(), entity.method_23321());
        return distanceFromCenter < radius;
    }

    private static boolean isParadis(class_1937 world) {
        return world.method_27983().toString().contains("dannys-aot:paradis");
    }

    private static boolean isDannyTitan(class_1297 entity) {
        String name = entity.getClass().getName();
        if (!name.startsWith("daot.")) {
            return false;
        }

        String simpleName = name.substring(name.lastIndexOf('.') + 1).toLowerCase();
        // These named AOT titans are covered explicitly; Sawney and Connie's Father
        // do not use the usual TitanEntity class suffix.
        // Some actual titans use names such as TitanTropicalEntity and TitanBeardEntity.
        // The named non-shifters below are included even though Sawney lacks "titan".
        boolean titanClass = simpleName.contains("titan")
                || simpleName.equals("sawneyentity")
                || simpleName.equals("titanbeardentity")
                || simpleName.equals("beardtitanentity")
                || simpleName.equals("conniefatherentity");
        if (!titanClass) {
            return false;
        }

        return !(simpleName.contains("nape") || simpleName.contains("eye")
                || simpleName.contains("grab") || simpleName.contains("leg")
                || simpleName.contains("hand")
                || simpleName.contains("spike") || simpleName.contains("shell")
                || simpleName.contains("projectile") || simpleName.contains("dummy"));
    }

    /** Danny's AOT marks every player-shift titan form with daot.ShifterTitan. */
    private static boolean isPlayerShifterForm(Class<?> entityClass) {
        for (Class<?> current = entityClass; current != null; current = current.getSuperclass()) {
            for (Class<?> implemented : current.getInterfaces()) {
                if (implemented.getName().equals("daot.ShifterTitan") || hasShifterMarker(implemented)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean hasShifterMarker(Class<?> type) {
        for (Class<?> parent : type.getInterfaces()) {
            if (parent.getName().equals("daot.ShifterTitan") || hasShifterMarker(parent)) {
                return true;
            }
        }
        return false;
    }
}
