package com.rocketsmp.paradisbreach;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_1297;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Stage 1 resets on each server start; operators advance the breach with commands. */
public final class ParadisWallBreachMod implements ModInitializer {
    private static final Logger LOGGER = Logger.getLogger("paradis_wall_breach_stages");
    private static final AtomicInteger STAGE = new AtomicInteger(1);
    private static final double[] INNER_BOUNDARIES = {13_660.0, 7_614.0, 1_616.0};

    @Override
    public void onInitialize() {
        STAGE.set(1);
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                registerCommands(dispatcher));
        LOGGER.info("Paradis Wall Breach Stages loaded at Stage 1 ("
                + (int) INNER_BOUNDARIES[0] + " block boundary).");
    }

    private static void registerCommands(CommandDispatcher<class_2168> dispatcher) {
        LiteralArgumentBuilder<class_2168> root = LiteralArgumentBuilder.<class_2168>literal("wallbreach")
                .requires(source -> source.method_9259(2))
                .then(LiteralArgumentBuilder.<class_2168>literal("stage1")
                        .executes(context -> setStage(context, 1)))
                .then(LiteralArgumentBuilder.<class_2168>literal("stage2")
                        .executes(context -> setStage(context, 2)))
                .then(LiteralArgumentBuilder.<class_2168>literal("stage3")
                        .executes(context -> setStage(context, 3)));
        dispatcher.register(root);
    }

    private static int setStage(CommandContext<class_2168> context, int stage) {
        STAGE.set(stage);
        double boundary = INNER_BOUNDARIES[stage - 1];
        context.getSource().method_9226(
                () -> class_2561.method_43470("Paradis wall breach stage " + stage
                        + " active. Titans may spawn outside " + (int) boundary + " blocks from the center."),
                false);
        return 1;
    }

    public static boolean shouldBlockTitanSpawn(class_1297 entity, Object world) {
        if (!isParadis(world) || !isDannyTitan(entity)) {
            return false;
        }

        double radius = INNER_BOUNDARIES[STAGE.get() - 1];
        double distanceFromCenter = Math.hypot(entity.method_23317(), entity.method_23321());
        return distanceFromCenter < radius;
    }

    private static boolean isParadis(Object world) {
        Object key = invoke(world, "method_27983");
        return key != null && key.toString().contains("dannys-aot:paradis");
    }

    private static boolean isDannyTitan(class_1297 entity) {
        String name = entity.getClass().getName();
        if (!name.startsWith("daot.")) {
            return false;
        }

        String simpleName = name.substring(name.lastIndexOf('.') + 1).toLowerCase();
        // These named AOT titans are covered explicitly; Sawney and Connie's Father
        // do not use the usual TitanEntity class suffix.
        boolean titanClass = simpleName.endsWith("titanentity")
                || simpleName.equals("sawneyentity")
                || simpleName.equals("mariotitanentity")
                || simpleName.equals("conniefatherentity");
        if (!titanClass) {
            return false;
        }

        return !(simpleName.contains("nape") || simpleName.contains("eye")
                || simpleName.contains("grab") || simpleName.contains("leg")
                || simpleName.contains("projectile") || simpleName.contains("dummy"));
    }

    private static Object invoke(Object target, String methodName) {
        try {
            Method method = target.getClass().getMethod(methodName);
            return method.invoke(target);
        } catch (ReflectiveOperationException exception) {
            LOGGER.log(Level.SEVERE, "Couldn't read the Paradis dimension key; allowing the entity spawn.", exception);
            return null;
        }
    }
}
